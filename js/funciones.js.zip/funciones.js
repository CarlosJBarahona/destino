function menu(e){

  $(".open-menu").click(function(e) {
      $('.links').css('left', '0');
      $('.links').css('opacity', '1'); 
      $('.cerrar-menu').css('left', '0');
  })

  $(".cerrar-menu").click(function(e) {
      $('.links').css('left', '-100%');
      $('.links').css('opacity', '0'); 
      $('.cerrar-menu').css('left', '-100%');
  })

   $(".cerrar-mensaje").click(function(e) {
      $('.title-men').css('display', 'none');
    
  })

}


function Home(){

  var owl = $(".slide-home");
 
    owl.owlCarousel({

      autoPlay: true, //Set AutoPlay to 3 seconds
      singleItem:true,
      pagination:true,
      slideSpeed:250,
      transitionStyle: "fade"


    });

    $(".next").click(function(){
    owl.trigger('owl.next');
    })
    $(".prev").click(function(){
      owl.trigger('owl.prev');
    })

}

function slide(){

  var owl = $(".slide-am");
 
    owl.owlCarousel({

      autoPlay: true, //Set AutoPlay to 3 seconds
      singleItem:true,
      pagination:true,
      slideSpeed:250,
      transitionStyle: "fade"


    });

    $(".nextpriv").click(function(){
    owl.trigger('owl.next');
    })
    $(".prevpriv").click(function(){
      owl.trigger('owl.prev');
    })

}

function slideam2(){

  var owl = $(".slide-am2");
 
    owl.owlCarousel({

      autoPlay: true, //Set AutoPlay to 3 seconds
      singleItem:true,
      pagination:true,
      slideSpeed:250,
      transitionStyle: "fade"


    });

    $(".next-am2").click(function(){
    owl.trigger('owl.next');
    })
    $(".prev-am2").click(function(){
      owl.trigger('owl.prev');
    })

}

function ubicacion(){

  var owl = $(".ubicacion");
 
    owl.owlCarousel({

      autoPlay: true, //Set AutoPlay to 3 seconds
      singleItem:true,
      pagination:true,
      slideSpeed:250,
      transitionStyle: "fade"


    });

    $(".nextubi").click(function(){
    owl.trigger('owl.next');
    })
    $(".prevubi").click(function(){
      owl.trigger('owl.prev');
    })
    setTimeout(function() {
      var imagena = parseInt($('.item-heig').css('height'));
      console.log('mide '+ imagena)
      $('.item-ubi').css('height', imagena);
    },600);

}

function slidehead(){

  var owl = $(".slide-head");
 
    owl.owlCarousel({

      autoPlay: true, //Set AutoPlay to 3 seconds
      singleItem:true,
      pagination:true,
      slideSpeed:250,
      transitionStyle: "fade"


    });

}


function contacto(){

  var ventana_ancho = $(window).width();

  $( ".contact-head" ).click(function(){
    $( ".form-hide" ).toggleClass( "active1" );
    $( ".cerrar-pop" ).toggleClass( "active1" );
    $( ".contact-head" ).toggleClass( "active1" );
    /*preventDefault();*/
    console.log('click')
  });

  $( ".cerrar-pop" ).click(function(){
    $( ".form-hide" ).toggleClass( "active1" );
    $( ".cerrar-pop" ).toggleClass( "active1" );
    $( ".contact-head" ).toggleClass( "active1" );
    /*preventDefault();*/
    console.log('click')
  });


  $(".cerrar-toggle").click(function(e) {
      if(ventana_ancho < 800){
        $('.links').css('left', '-100%');
        $('.links').css('opacity', '0'); 
        $('.cerrar-menu').css('left', '-100%');
      }
    
  })




}

function recorrido(){

  console.log('videos')

  var sync2 = $("#recorrido");
 
  sync2.owlCarousel({
    singleItem : true,
    slideSpeed : 1000,
    navigation: true,
    pagination:false,
    transitionStyle : "fade",
    afterAction : syncPosition,
    responsiveRefreshRate : 200,
  });

  $(".next-big").click(function(){
      sync2.trigger('owl.next');
    })

  $(".prev-big").click(function(){
    sync2.trigger('owl.prev');
  });

  /******************/

  function syncPosition(el){
    var current = this.currentItem;
    $("#sync3")
      .find(".owl-item")
      .removeClass("synced")
      .eq(current)
      .addClass("synced")
    if($("#sync3").data("owlCarousel") !== undefined){
      center(current)
    }
  }
 
  $("#sync3").on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).data("owlItem");
    sync2.trigger("owl.goTo",number);
  });
 
  function center(number){
    var syncvisible = syncr.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in syncvisible){
      if(num === syncvisible[i]){
        var found = true;
      }
    }
 
    if(found===false){
      if(num>syncvisible[syncvisible.length-1]){
        syncr.trigger("owl.goTo", num - syncvisible.length+2)
      }else{
        if(num - 1 === -1){
          num = 0;
        }
        syncr.trigger("owl.goTo", num);
      }
    } else if(num === syncvisible[syncvisible.length-1]){
      syncr.trigger("owl.goTo", syncvisible[1])
    } else if(num === syncvisible[0]){
      syncr.trigger("owl.goTo", num-1)
    }
    
  }


  /******************/

  var syncr = $("#sync3");
 
  syncr.owlCarousel({
    items : 4,
    itemsDesktop : [1000,4], //5 items between 1000px and 901px
    itemsDesktopSmall : [900,4], // betweem 900px and 601px
    itemsTablet: [600,3], //2 items between 600 and 0
    itemsMobile : [400,3], // itemsMobile disabled - inherit from itemsTablet option
    singleItem : false,
    pagination:false,
    responsiveRefreshRate : 100,
    afterInit : function(el){
      el.find(".owl-item").eq(0).addClass("synced");
    }
  });

  $(".siguiente").click(function(){
      syncr.trigger('owl.next');
    })

  $(".anterior").click(function(){
    syncr.trigger('owl.prev');
  });

}


function videos(){

  console.log('videos')

  var sync1 = $("#video");
 
  sync1.owlCarousel({
    singleItem : true,
    slideSpeed : 1000,
    navigation: true,
    pagination:false,
    transitionStyle : "fade",
    afterAction : syncPosition,
    responsiveRefreshRate : 200,
  });

  $(".next-big").click(function(){
      sync1.trigger('owl.next');
    })

  $(".prev-big").click(function(){
    sync1.trigger('owl.prev');
  });

  /******************/

  function syncPosition(el){
    var current = this.currentItem;
    $("#sync")
      .find(".owl-item")
      .removeClass("synced")
      .eq(current)
      .addClass("synced")
    if($("#sync").data("owlCarousel") !== undefined){
      center(current)
    }
  }
 
  $("#sync").on("click", ".owl-item", function(e){
    e.preventDefault();
    var number = $(this).data("owlItem");
    sync1.trigger("owl.goTo",number);
  });
 
  function center(number){
    var syncvisible = sync.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in syncvisible){
      if(num === syncvisible[i]){
        var found = true;
      }
    }
 
    if(found===false){
      if(num>syncvisible[syncvisible.length-1]){
        sync.trigger("owl.goTo", num - syncvisible.length+2)
      }else{
        if(num - 1 === -1){
          num = 0;
        }
        sync.trigger("owl.goTo", num);
      }
    } else if(num === syncvisible[syncvisible.length-1]){
      sync.trigger("owl.goTo", syncvisible[1])
    } else if(num === syncvisible[0]){
      sync.trigger("owl.goTo", num-1)
    }
    
  }


  /******************/

  var sync = $("#sync");
 
  sync.owlCarousel({
    items : 4,
    itemsDesktop : [1000,4], //5 items between 1000px and 901px
    itemsDesktopSmall : [900,4], // betweem 900px and 601px
    itemsTablet: [600,3], //2 items between 600 and 0
    itemsMobile : [400,3], // itemsMobile disabled - inherit from itemsTablet option
    singleItem : false,
    pagination:false,
    responsiveRefreshRate : 100,
    afterInit : function(el){
      el.find(".owl-item").eq(0).addClass("synced");
    }
  });

  $(".next-small").click(function(){
      sync.trigger('owl.next');
    })

  $(".prev-small").click(function(){
    sync.trigger('owl.prev');
  });

}


function modals(e){

  $(".open-notice").click(function(e) {
        var id_notice = $(this).attr("notice");
        $('.cont-modal').css({'height' : '0', 'opacity' : '0'});
        $('.container-modals').css({'margin-top' : '100%'});
        if ($('.'+id_notice).css('height') == "0px"){
            $('.'+id_notice).css({'height' : '100%', 'opacity' : '1'});
            setTimeout(function() {
                $('.container-modals').css({'margin-top' : '0'});
            },500);
        }
        console.log(id_notice);
    })

    $(".close-modals").click(function(e) {
        
        $('.container-modals').css({'margin-top' : '100%'});
        setTimeout(function() {
            $('.cont-modal').css({'height' : '0', 'opacity' : '0'});
        },500);
    })

    $(".x-modals").click(function(e) {
        
        $('.container-modals').css({'margin-top' : '100%'});
        setTimeout(function() {
            $('.cont-modal').css({'height' : '0', 'opacity' : '0'});
        },500);
    })

}


$(document).ready(function() {

  menu();
  Home();
  videos();
  contacto();
  slide();
  modals();
  recorrido();
  ubicacion();
  slidehead();
  slideam2()

  
});

$( window ).resize(function() {
  
   ubicacion();
});






/* Mapa */


//img to svg
$(document).ready(function() {
//img tag to svg 
jQuery('img.svg').each(function(){
    var $img = jQuery(this);
    var imgID = $img.attr('id');
    var imgClass = $img.attr('class');
    var imgURL = $img.attr('src');

    jQuery.get(imgURL, function(data) {
        // Get the SVG tag, ignore the rest
        var $svg = jQuery(data).find('svg');

        // Add replaced image's ID to the new SVG
        if(typeof imgID !== 'undefined') {
            $svg = $svg.attr('id', imgID);
        }
        // Add replaced image's classes to the new SVG
        if(typeof imgClass !== 'undefined') {
            $svg = $svg.attr('class', imgClass+' replaced-svg');
        }

        // Remove any invalid XML tags as per http://validator.w3.org
        $svg = $svg.removeAttr('xmlns:a');

        // Check if the viewport is set, if the viewport is not set the SVG wont't scale.
        if(!$svg.attr('viewBox') && $svg.attr('height') && $svg.attr('width')) {
            $svg.attr('viewBox', '0 0 ' + $svg.attr('height') + ' ' + $svg.attr('width'))
        }

        // Replace image with new SVG
        $img.replaceWith($svg);

    }, 'xml');

});


});
////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////interactive map//////////////////////////
var img ;
var width;
var height;
var c;
var ctx; 
function runInteractiveMap(){
  // if($.browser.msie == true){
  //   $("#mapCanvas").css("display","none");
  //   $("#mapDiv").css("display","none");
  //   return 0;
  // }
  (function() {
    var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame;
    window.requestAnimationFrame = requestAnimationFrame;
  })();

  img = document.getElementById('mapWrap');
  c = document.getElementById('mapCanvas');
  ctx = c.getContext("2d"); 
  
  updateCanvas();
  loadVectors();
  drawVectors();
  setMouseHandler();
  mainLoop();

  window.addEventListener("resize",function(){
      updateCanvas();
  });
}

var screenWidth;
function updateCanvas(){

  img = document.getElementById('mapImg');
  width = parseInt(window.getComputedStyle(img, null).getPropertyValue("width"));
  height = parseInt(window.getComputedStyle(img, null).getPropertyValue("height"));

  c.width = width;
  c.height = height;

  $("#mapDiv").css("width",width);
  $("#mapDiv").css("height",height);

  screenWidth = $(window).width();

  updateInfoPos();
  drawVectors();
}

//////////////////////////////////////////////////support

function getPos(num , position){
  if(position ="w"){
    return (c.width/100)*num;
  }
  else if(position ="h"){
    return (c.width/100)*num;
  }
}
function getInvPos(num , position){
  if(position ="w"){
    return (num*100)/c.width;
  }
  else if(position ="h"){
    return (num*100)/c.height;
  }
}

function checkCol(){
    for(var i = 0; i<vectors.length; i++){

      var temp  = vectors[i].x+vectors[i].width;
      var temp1 = vectors[i].x;
      var temp2 = vectors[i].y+vectors[i].height;
      var temp3 = vectors[i].y;
     
      if(mousePos.x < temp && mousePos.x > temp1 && mousePos.y < temp2 && mousePos.y > temp3){
         // console.log("colide"+i);
         return i;
      }
    }
    return null;
}

///////////////////////////////////////////////////////////mouse handler
var mousePos = 0;
function getMousePos(e) {
    var rect = c.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
}

var inCanvas = null;
var clickedOn = null;
function setMouseHandler(){
  
  /*  c.addEventListener('mousemove', function(evt) {
    
     if(screenWidth < 720){
      return 0;
     }
     
     mousePos = getMousePos(evt);
     mousePos.x = getInvPos(mousePos.x,"w");
     mousePos.y = getInvPos(mousePos.y,"h");
     clickedOn=checkCol();
    }, false);
  */
/*
    if(screenWidth > 720){

      c.addEventListener('mousemove', function(evt) {

       mousePos = getMousePos(evt);
       mousePos.x = getInvPos(mousePos.x,"w");
       mousePos.y = getInvPos(mousePos.y,"h");
       clickedOn=checkCol();
      }, false);

    }
*/
  c.addEventListener('click', function(evt) {

       mousePos = getMousePos(evt);
       mousePos.x = getInvPos(mousePos.x,"w");
       mousePos.y = getInvPos(mousePos.y,"h");
       clickedOn=checkCol();
      }, false);  
  
  $("#mapCanvas")
  .mouseenter(function() {
   $('.container').css('user-select','none');
   $('.container').css('-webkit-user-select','none');
   $('.container').css('-moz-user-select','none');
   inCanvas = true;
   // mainLoop();
  })

  .mouseenter(function() {
   $('.icon-cerrar').css('user-select','none');
   $('.icon-cerrar').css('-webkit-user-select','none');
   $('.icon-cerrar').css('-moz-user-select','none');
   inCanvas = true;
   // mainLoop();
  })

  .mouseleave(function() {
   $('.container').css('user-select','initial');
   $('.container').css('-webkit-user-select','initial');
   $('.container').css('-moz-user-select','initial');
   inCanvas = false;
   mousePos.x = -10;
   mousePos.y = -10;
  });


  // c.addEventListener('mousemove', function(evt) {
  //   mousePos = getMousePos(evt);
  //   mousePos.x = getInvPos(mousePos.x,"w");
  //   mousePos.y = getInvPos(mousePos.y,"h");
  // }, false);
  // c.addEventListener('click', function(evt) {
  //   var mousePos1 = getMousePos(evt);
  //   mousePos1.x = getInvPos(mousePos1.x,"w");
  //   mousePos1.y = getInvPos(mousePos1.y,"h");
  //   console.log(mousePos1);
  // }, false);
}


////////////////////////////////////////////////////////locations
var pins=document.getElementsByClassName("pinMap");
var vectors = [];
function vector(){} 
vector.prototype ={
  contructor:vector,
  name:"",
  size:"",
  x:0,
  y:0,
  width:2,
  height:2,
  infoX:0,
  infoY:0,
  status:"idle",
}

function loadVectors(){

  screenWidth = $(window).width();

  vectors = [];
  vectors.push(new vector());
  vectors[vectors.length-1].name = "0";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 38;
  vectors[vectors.length-1].y = 28;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
    /*
    vectors[vectors.length-1].infoX = '40%';
    vectors[vectors.length-1].infoY = '35%';
    */
  }

  vectors.push(new vector());
  vectors[vectors.length-1].name = "1";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 44;
  vectors[vectors.length-1].y = 25;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
  /*
  vectors[vectors.length-1].infoX = '40%';
  vectors[vectors.length-1].infoY = '36%';
  */
  }

  vectors.push(new vector());
  vectors[vectors.length-1].name = "2";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 40;
  vectors[vectors.length-1].y = 15;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
  /*
  vectors[vectors.length-1].infoX = '40%';
  vectors[vectors.length-1].infoY = '15%';
  */
  }

  vectors.push(new vector());
  vectors[vectors.length-1].name = "4";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 48;
  vectors[vectors.length-1].y = 25;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
  /*
  vectors[vectors.length-1].infoX = '48%';
  vectors[vectors.length-1].infoY = '25%';
  */
  }
  
  vectors.push(new vector());
  vectors[vectors.length-1].name = "5";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 45;
  vectors[vectors.length-1].y = 30;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
  /*
  vectors[vectors.length-1].infoX = '45%';
  vectors[vectors.length-1].infoY = '30%';
  */
  }

  vectors.push(new vector());
  vectors[vectors.length-1].name = "6";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 78;
  vectors[vectors.length-1].y = 26;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
  /*
  vectors[vectors.length-1].infoX = '65%';
  vectors[vectors.length-1].infoY = '28%';
  */
  }

  vectors.push(new vector());
  vectors[vectors.length-1].name = "7";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 75;
  vectors[vectors.length-1].y = 30;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
  /*
  vectors[vectors.length-1].infoX = '60%';
  vectors[vectors.length-1].infoY = '32%';
  */
  }

  vectors.push(new vector());
  vectors[vectors.length-1].name = "8";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 74;
  vectors[vectors.length-1].y = 27;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '30%';
    vectors[vectors.length-1].infoY = '35%';
  /*
  vectors[vectors.length-1].infoX = '60%';
  vectors[vectors.length-1].infoY = '32%';
  */
  }

  vectors.push(new vector());
  vectors[vectors.length-1].name = "9";
  vectors[vectors.length-1].size = "medium";
  vectors[vectors.length-1].x = 7;
  vectors[vectors.length-1].y = 4;
  if(screenWidth < 720){
    vectors[vectors.length-1].infoX = '0%';
    vectors[vectors.length-1].infoY = '0%';
  }else if (screenWidth > 720) {
    vectors[vectors.length-1].infoX = '8%';
    vectors[vectors.length-1].infoY = '10%';
  /*
  vectors[vectors.length-1].infoX = '40%';
  vectors[vectors.length-1].infoY = '15%';
  */
  }
}
function drawVectors(){
  for(var i = 0 ; i < vectors.length; i++){
    //show info in position
    temp = ".pin"+i;
    
    if(vectors[i].size=="small"){
      $(temp).css('left',getPos(vectors[i].x-0.5));
      $(temp).css('top',getPos(vectors[i].y));
      $(temp).css('height',getPos(3));
    }
    else if(vectors[i].size=="medium"){
      $(temp).css('left',getPos(vectors[i].x-0.8));
      $(temp).css('top',getPos(vectors[i].y));
      $(temp).css('height',getPos(8));
    }
    else if(vectors[i].size=="big"){
      $(temp).css('left',getPos(vectors[i].x-1.5));
      $(temp).css('top',getPos(vectors[i].y));
      $(temp).css('height',getPos(6));
    }

    if(vectors[i].status!="idle"){
      $(temp).addClass("pinSelected");
      if(vectors[i].size=="small"){
        /*$(temp).css('left',getPos(vectors[i].x-1.8));*/
        /*$(temp).css('top',getPos(vectors[i].y-2.5));*/
        $(temp).css('height',getPos(6.5));
      }
      else if(vectors[i].size=="medium"){
        /*$(temp).css('left',getPos(vectors[i].x-1.8));*/
        /*$(temp).css('top',getPos(vectors[i].y-2));*/
        $(temp).css('height',getPos(8));
      }
      else if(vectors[i].size=="big"){
        /*$(temp).css('left',getPos(vectors[i].x-1.6));*/
        /*$(temp).css('top',getPos(vectors[i].y-0.5));*/
        $(temp).css('height',getPos(6.5));
      }
    }
    else{
      $(temp).removeClass("pinSelected")
    }
  }
}
function resetVectorsStatus(from){
  for(var i=0; i<vectors.length; i++){
    if(vectors[i].status==from){
      vectors[i].status="idle";
    }
  }
}
function updateInfoPos(){
  for(var i= 0; i<vectors.length; i++){
    if(vectors[i].status=="showing"){
       showMapInfo(i);
       return;
    }
  }
  return;
}
function showMapInfo(arrayLoc){
  $('#locationContainer').hide();
  var infos = document.getElementsByClassName("infoContent");
  for(var i= 0; i<infos.length; i++){
    var temp = ".mapInfo"+i;
    $(temp).hide();
  }
  //show info in position
  temp = ".mapInfo"+arrayLoc;
  $(temp).show();
 
  if($(window).width() >= 720){
    $('#locationContainer').css('left',vectors[arrayLoc].infoX);
    $('#locationContainer').css('top',vectors[arrayLoc].infoY);
  }
  else{
    $('#locationContainer').css('left','0');
    $('#locationContainer').css('top','0');
  }
  
  
  $('#locationContainer').fadeIn(300);
  
  resetVectorsStatus("showing");
  vectors[arrayLoc].status="showing";
}
function closeMapInfo(){
    $('#locationContainer').hide();

    
    resetVectorsStatus("showing");
    clickedOn=null;
}

/////////////////////////////////////////////main////////////////////////////////////
function mainLoop(){
    ctx.clearRect(0,0,c.width,c.height); //borra el canvas actual
    drawVectors();

    resetVectorsStatus("expand");
    var temp = checkCol();
    if(temp != null){
        if(vectors[temp].status=="idle"){
          vectors[temp].status="expand";
        }
    }


    ////////////////////////mouse clicked event//////////////

    if(clickedOn != null){
      if(vectors[clickedOn].status!="showing"){
        showMapInfo(clickedOn);
      }
    }
    else if(clickedOn == null){ 
      closeMapInfo();
    }

    $( ".icon-cerrar" ).click(function(){
      closeMapInfo();
    });
    
    requestAnimationFrame(mainLoop);
}